# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['menage_jupyter']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'convert-jupyter',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Menage jupyter \nThis project help menage jupyter flie.\nIt let:\n    - convert .ipynb to .py file\n    - convert .py to .ipynb file\n    - clean output jupyter\n\n\n## autors\nBartłomiej Chwiłkowski (github: chwilko)\n\n\n# Structure\nmenage_jupyter:\n    - file with functions\n\n\n## Functions \n\njupyter2py(f_in_name: str, f_out_name: str = None)\npy2jupyter(f_in_name: str, f_out_name: str = None)\nclean(path: str)\n\n## Licence\nMIT',
    'author': 'Bartłomiej Chwiłkowski',
    'author_email': 'bartekchwilkowski@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
