
## Licence
CC BY
https://creativecommons.org/licenses/?lang=pl