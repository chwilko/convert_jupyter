CELL_SEPARATOR = "# New cell\n"
MARKDOWN_BEGIN = "'''md\n"
MARKDOWN_END = "\n'''"
