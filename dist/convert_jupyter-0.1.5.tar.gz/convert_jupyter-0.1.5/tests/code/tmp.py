"""md
## imports
"""
# New cell
import matplotlib.pyplot as plt
import numpy as np

# New cell
"""md
## initialize


"""
# New cell
X = np.arange(0, 100)
# New cell
Y = np.random.random(size=[100])
# New cell
"""md
## plot
"""
# New cell
plt.plot(X, Y)
